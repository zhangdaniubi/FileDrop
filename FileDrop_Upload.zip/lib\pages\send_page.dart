import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:file_picker/file_picker.dart';

import '../models/device_model.dart';
import '../models/transfer_task_model.dart';
import '../providers/device_provider.dart';
import '../providers/transfer_provider.dart';
import '../services/http_service.dart';
import '../services/discovery_service.dart';
import '../services/file_service.dart';
import '../widgets/transfer_progress_card.dart';

class SendPage extends StatefulWidget {
  final List<PlatformFile> files;
  final DeviceInfo targetDevice;

  const SendPage({
    super.key,
    required this.files,
    required this.targetDevice,
  });

  @override
  State<SendPage> createState() => _SendPageState();
}

class _SendPageState extends State<SendPage> {
  bool _sending = false;

  Future<void> _sendFiles() async {
    if (_sending) return;
    setState(() => _sending = true);

    for (final file in widget.files) {
      if (file.path == null) continue;

      final taskId = 'T-${DateTime.now().millisecondsSinceEpoch}-${file.hashCode}';
      final task = TransferTask(
        taskId: taskId,
        fileName: file.name,
        fileSize: file.size,
        direction: 'send',
        targetDeviceId: widget.targetDevice.deviceId,
        targetDeviceName: widget.targetDevice.deviceName,
      );

      context.read<TransferProvider>().addTask(task);

      final httpService = HttpService();
      final result = await httpService.uploadFile(
        ip: widget.targetDevice.ipAddress,
        port: widget.targetDevice.httpPort,
        filePath: file.path!,
        fileName: file.name,
        onProgress: (progress, speed) {
          context.read<TransferProvider>().updateProgress(taskId, progress, speed);
        },
      );

      if (result.containsKey('error')) {
        context.read<TransferProvider>().completeTask(taskId, 'failed');
      } else {
        context.read<TransferProvider>().completeTask(taskId, 'completed');
      }
    }

    setState(() => _sending = false);

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('文件发送完成')),
      );
      Navigator.of(context).pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('发送文件')),
      body: Column(
        children: [
          // 目标设备信息
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(16),
            color: Theme.of(context).colorScheme.primaryContainer,
            child: Row(
              children: [
                Icon(Icons.arrow_upward_rounded,
                    color: Theme.of(context).colorScheme.primary),
                const SizedBox(width: 8),
                Text('发送到: ', style: Theme.of(context).textTheme.bodyMedium),
                Text(
                  widget.targetDevice.deviceName,
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                ),
              ],
            ),
          ),

          // 文件列表
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: widget.files.length,
              itemBuilder: (context, index) {
                final file = widget.files[index];
                return Card(
                  child: ListTile(
                    leading: const Icon(Icons.insert_drive_file_rounded),
                    title: Text(file.name),
                    subtitle: Text(FileService.formatFileSize(file.size)),
                  ),
                );
              },
            ),
          ),

          // 发送按钮
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: SizedBox(
                width: double.infinity,
                height: 48,
                child: FilledButton.icon(
                  onPressed: _sending ? null : _sendFiles,
                  icon: _sending
                      ? const SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : const Icon(Icons.send_rounded),
                  label: Text(_sending ? '发送中...' : '发送 ${widget.files.length} 个文件'),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
