import 'package:flutter/foundation.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

class NotificationService {
  final FlutterLocalNotificationsPlugin _plugin = FlutterLocalNotificationsPlugin();
  bool _initialized = false;

  Future<void> init() async {
    if (_initialized) return;
    try {
      const androidSettings = AndroidInitializationSettings('@mipmap/ic_launcher');
      const iosSettings = DarwinInitializationSettings(
        requestAlertPermission: true,
        requestBadgePermission: true,
        requestSoundPermission: true,
      );

      const settings = InitializationSettings(
        android: androidSettings,
        iOS: iosSettings,
      );

      await _plugin.initialize(settings);
      _initialized = true;
      debugPrint('[FileDrop] Notification service initialized');
    } catch (e) {
      debugPrint('[FileDrop] Notification init error: $e');
    }
  }

  Future<void> showFileReceivedNotification({
    required String fileName,
    required String deviceName,
  }) async {
    if (!_initialized) return;
    try {
      const androidDetails = AndroidNotificationDetails(
        'file_drop_channel',
        'FileDrop 传输通知',
        channelDescription: '文件传输完成通知',
        importance: Importance.high,
        priority: Priority.high,
        showWhen: true,
      );

      const iosDetails = DarwinNotificationDetails();

      const details = NotificationDetails(
        android: androidDetails,
        iOS: iosDetails,
      );

      await _plugin.show(
        DateTime.now().millisecondsSinceEpoch ~/ 1000,
        '文件接收完成',
        '从 $deviceName 收到: $fileName',
        details,
      );
    } catch (e) {
      debugPrint('[FileDrop] Show notification error: $e');
    }
  }

  Future<void> showTransferCompleteNotification({
    required String fileName,
    required String deviceName,
    required String direction,
  }) async {
    if (!_initialized) return;
    final title = direction == 'send' ? '文件发送完成' : '文件接收完成';
    final body = direction == 'send'
        ? '已发送到 $deviceName: $fileName'
        : '从 $deviceName 收到: $fileName';

    try {
      const androidDetails = AndroidNotificationDetails(
        'file_drop_channel',
        'FileDrop 传输通知',
        importance: Importance.high,
        priority: Priority.high,
      );

      const details = NotificationDetails(android: androidDetails);

      await _plugin.show(
        DateTime.now().millisecondsSinceEpoch ~/ 1000,
        title,
        body,
        details,
      );
    } catch (e) {
      debugPrint('[FileDrop] Transfer notification error: $e');
    }
  }
}
