class TransferRecord {
  int id;
  final String fileName;
  final String fileSize;
  final String direction;
  final String peerDeviceName;
  final String status;
  final double speed;
  final DateTime createdAt;
  final DateTime? completedAt;

  TransferRecord({
    this.id = 0,
    required this.fileName,
    required this.fileSize,
    required this.direction,
    required this.peerDeviceName,
    required this.status,
    this.speed = 0,
    required this.createdAt,
    this.completedAt,
  });

  Map<String, dynamic> toJson() => {
    'id': id,
    'fileName': fileName,
    'fileSize': fileSize,
    'direction': direction,
    'peerDeviceName': peerDeviceName,
    'status': status,
    'speed': speed,
    'createdAt': createdAt.toIso8601String(),
    'completedAt': completedAt?.toIso8601String(),
  };

  factory TransferRecord.fromJson(Map<String, dynamic> json) => TransferRecord(
    id: json['id'] ?? 0,
    fileName: json['fileName'] ?? '',
    fileSize: json['fileSize'] ?? '',
    direction: json['direction'] ?? '',
    peerDeviceName: json['peerDeviceName'] ?? '',
    status: json['status'] ?? '',
    speed: (json['speed'] ?? 0).toDouble(),
    createdAt: DateTime.parse(json['createdAt'] ?? DateTime.now().toIso8601String()),
    completedAt: json['completedAt'] != null ? DateTime.tryParse(json['completedAt']) : null,
  );
}
