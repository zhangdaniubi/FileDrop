import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/storage_service.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  late TextEditingController _nameController;
  bool _autoAccept = false;
  bool _darkMode = false;

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController();
    _loadSettings();
  }

  void _loadSettings() {
    final storage = context.read<StorageService>();
    _nameController.text = storage.deviceName;
    _autoAccept = storage.autoAccept;
    _darkMode = storage.isDarkMode;
  }

  @override
  void dispose() {
    _nameController.dispose();
    super.dispose();
  }

  void _saveDeviceName(String name) {
    context.read<StorageService>().deviceName = name;
  }

  void _toggleAutoAccept(bool val) {
    setState(() => _autoAccept = val);
    context.read<StorageService>().autoAccept = val;
  }

  void _toggleDarkMode(bool val) {
    setState(() => _darkMode = val);
    context.read<StorageService>().isDarkMode = val;
    // Rebuild the app to apply theme
    // In a real app, you'd need to rebuild MaterialApp - using a ThemeMode notifier
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        // 设备设置
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('设备设置',
                    style: Theme.of(context).textTheme.titleSmall?.copyWith(
                          fontWeight: FontWeight.w600,
                        )),
                const SizedBox(height: 12),
                TextField(
                  controller: _nameController,
                  decoration: const InputDecoration(
                    labelText: '设备昵称',
                    hintText: '输入设备名称（如：我的手机）',
                    prefixIcon: Icon(Icons.label_rounded),
                  ),
                  onChanged: _saveDeviceName,
                ),
                const SizedBox(height: 8),
                Text(
                  '其他设备将看到此名称',
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: Theme.of(context).colorScheme.outline,
                      ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),

        // 传输设置
        Card(
          child: Column(
            children: [
              SwitchListTile(
                title: const Text('自动接收文件'),
                subtitle: const Text('开启后自动保存接收的文件到下载目录'),
                value: _autoAccept,
                onChanged: _toggleAutoAccept,
                secondary: const Icon(Icons.autorenew_rounded),
              ),
              const Divider(height: 1, indent: 16, endIndent: 16),
              SwitchListTile(
                title: const Text('暗色模式'),
                subtitle: const Text('切换应用主题，下次启动生效'),
                value: _darkMode,
                onChanged: _toggleDarkMode,
                secondary: const Icon(Icons.dark_mode_rounded),
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),

        // 关于
        Card(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
                child: Text('关于',
                    style: Theme.of(context).textTheme.titleSmall?.copyWith(
                          fontWeight: FontWeight.w600,
                        )),
              ),
              ListTile(
                leading: const Icon(Icons.info_outline_rounded),
                title: const Text('FileDrop'),
                subtitle: const Text('v1.0.0 • 跨平台文件互传工具'),
              ),
              ListTile(
                leading: const Icon(Icons.folder_rounded),
                title: const Text('文件保存位置'),
                subtitle: const Text('应用文档目录/FileDrop'),
              ),
            ],
          ),
        ),
        const SizedBox(height: 32),
        Center(
          child: Text(
            'FileDrop v1.0.0',
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: Theme.of(context).colorScheme.outline,
                ),
          ),
        ),
      ],
    );
  }
}
