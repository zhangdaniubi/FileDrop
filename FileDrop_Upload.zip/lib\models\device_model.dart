class DeviceInfo {
  final String deviceId;
  final String deviceName;
  final String deviceType;
  final String osVersion;
  final String platform;
  final String ipAddress;
  final int httpPort;
  bool isOnline;
  DateTime lastSeen;

  DeviceInfo({
    required this.deviceId,
    required this.deviceName,
    this.deviceType = '',
    this.osVersion = '',
    this.platform = 'mobile',
    required this.ipAddress,
    this.httpPort = 9121,
    this.isOnline = true,
    DateTime? lastSeen,
  }) : lastSeen = lastSeen ?? DateTime.now();

  factory DeviceInfo.fromJson(Map<String, dynamic> json) {
    return DeviceInfo(
      deviceId: json['deviceId'] ?? '',
      deviceName: json['deviceName'] ?? '',
      deviceType: json['deviceType'] ?? '',
      osVersion: json['osVersion'] ?? '',
      platform: json['platform'] ?? 'mobile',
      ipAddress: json['ipAddress'] ?? '',
      httpPort: json['httpPort'] ?? 9121,
      isOnline: json['isOnline'] ?? true,
      lastSeen: json['lastSeen'] != null
          ? DateTime.tryParse(json['lastSeen']) ?? DateTime.now()
          : DateTime.now(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'deviceId': deviceId,
      'deviceName': deviceName,
      'deviceType': deviceType,
      'osVersion': osVersion,
      'platform': platform,
      'ipAddress': ipAddress,
      'httpPort': httpPort,
      'isOnline': isOnline,
      'lastSeen': lastSeen.toIso8601String(),
    };
  }

  String get displayName => deviceName.isNotEmpty ? deviceName : deviceId.substring(0, 8);

  @override
  bool operator ==(Object other) =>
      identical(this, other) || other is DeviceInfo && deviceId == other.deviceId;

  @override
  int get hashCode => deviceId.hashCode;
}
