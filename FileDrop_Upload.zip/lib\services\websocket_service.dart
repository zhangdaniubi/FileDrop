import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:web_socket_channel/web_socket_channel.dart';

class WebSocketService {
  WebSocketChannel? _channel;
  bool _connected = false;

  final StreamController<Map<String, dynamic>> _progressController =
      StreamController<Map<String, dynamic>>.broadcast();
  final StreamController<Map<String, dynamic>> _completeController =
      StreamController<Map<String, dynamic>>.broadcast();
  final StreamController<Map<String, dynamic>> _failedController =
      StreamController<Map<String, dynamic>>.broadcast();

  Stream<Map<String, dynamic>> get onProgress => _progressController.stream;
  Stream<Map<String, dynamic>> get onComplete => _completeController.stream;
  Stream<Map<String, dynamic>> get onFailed => _failedController.stream;

  bool get isConnected => _connected;

  void connect(String ip, int port) {
    if (_connected) return;
    try {
      final uri = Uri.parse('ws://$ip:$port/socket.io/?EIO=4&transport=websocket');
      _channel = WebSocketChannel.connect(uri);
      _connected = true;

      _channel!.stream.listen(
        (data) {
          _handleMessage(data.toString());
        },
        onError: (error) {
          debugPrint('[FileDrop] WebSocket error: $error');
          _connected = false;
        },
        onDone: () {
          debugPrint('[FileDrop] WebSocket disconnected');
          _connected = false;
        },
      );

      // Socket.IO 握手
      _sendRaw('40'); // Socket.IO v4 connect packet
      debugPrint('[FileDrop] WebSocket connected to $ip:$port');
    } catch (e) {
      debugPrint('[FileDrop] WebSocket connect error: $e');
      _connected = false;
    }
  }

  void disconnect() {
    _channel?.sink.close();
    _channel = null;
    _connected = false;
    debugPrint('[FileDrop] WebSocket disconnected');
  }

  void _sendRaw(String data) {
    _channel?.sink.add(data);
  }

  void _handleMessage(String message) {
    try {
      // Socket.IO 协议解析
      if (message.startsWith('0')) {
        // 打开连接
        _sendRaw('40');
      } else if (message == '2') {
        // ping
        _sendRaw('3'); // pong
      } else if (message.startsWith('42')) {
        // Socket.IO event: 42["event",{...}]
        final jsonStr = message.substring(2);
        final data = jsonDecode(jsonStr) as List<dynamic>;
        if (data.length < 2) return;

        final event = data[0] as String;
        final payload = data[1] as Map<String, dynamic>;

        switch (event) {
          case 'progress':
            _progressController.add(payload);
            break;
          case 'complete':
            _completeController.add(payload);
            break;
          case 'failed':
            _failedController.add(payload);
            break;
        }
      }
    } catch (e) {
      debugPrint('[FileDrop] WebSocket message parse error: $e');
    }
  }

  void dispose() {
    disconnect();
    _progressController.close();
    _completeController.close();
    _failedController.close();
  }
}
