import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';

class FileService {
  String? _downloadDir;

  Future<String> getDownloadDirectory() async {
    if (_downloadDir != null) return _downloadDir!;
    final dir = await getApplicationDocumentsDirectory();
    _downloadDir = '${dir.path}/FileDrop';
    final downloadDir = Directory(_downloadDir!);
    if (!await downloadDir.exists()) {
      await downloadDir.create(recursive: true);
    }
    return _downloadDir!;
  }

  Future<String> saveReceivedFile(String fileName, List<int> bytes) async {
    final dir = await getDownloadDirectory();

    // 处理同名文件
    String finalPath = '$dir/$fileName';
    int counter = 1;
    while (await File(finalPath).exists()) {
      final dotIndex = fileName.lastIndexOf('.');
      if (dotIndex > 0) {
        final name = fileName.substring(0, dotIndex);
        final ext = fileName.substring(dotIndex);
        finalPath = '$dir/${name}_($counter)$ext';
      } else {
        finalPath = '$dir/${fileName}_($counter)';
      }
      counter++;
    }

    final file = File(finalPath);
    await file.writeAsBytes(bytes);
    debugPrint('[FileDrop] File saved: $finalPath');
    return finalPath;
  }

  static String formatFileSize(int bytes) {
    if (bytes < 1024) return '$bytes B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
    if (bytes < 1024 * 1024 * 1024) {
      return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
    }
    return '${(bytes / (1024 * 1024 * 1024)).toStringAsFixed(1)} GB';
  }

  Future<List<FileSystemEntity>> listReceivedFiles() async {
    final dir = await getDownloadDirectory();
    final downloadDir = Directory(dir);
    if (!await downloadDir.exists()) return [];
    return downloadDir.list().toList();
  }

  Future<void> deleteFile(String path) async {
    final file = File(path);
    if (await file.exists()) {
      await file.delete();
    }
  }

  void setDownloadDir(String path) {
    _downloadDir = path;
    final dir = Directory(path);
    if (!dir.existsSync()) {
      dir.createSync(recursive: true);
    }
  }
}
