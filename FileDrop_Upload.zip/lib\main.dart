import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'app/app_theme.dart';
import 'app/app_root.dart';
import 'services/discovery_service.dart';
import 'services/http_service.dart';
import 'services/file_service.dart';
import 'services/storage_service.dart';
import 'services/notification_service.dart';
import 'providers/device_provider.dart';
import 'providers/transfer_provider.dart';
import 'providers/history_provider.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  final storageService = StorageService();
  await storageService.init();

  final notificationService = NotificationService();
  await notificationService.init();

  final discoveryService = DiscoveryService();
  final httpService = HttpService();
  final fileService = FileService();

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => DeviceProvider(discoveryService)),
        ChangeNotifierProvider(create: (_) => TransferProvider()),
        ChangeNotifierProvider(create: (_) => HistoryProvider(storageService)),
        Provider<StorageService>.value(value: storageService),
        Provider<DiscoveryService>.value(value: discoveryService),
        Provider<HttpService>.value(value: httpService),
        Provider<FileService>.value(value: fileService),
        Provider<NotificationService>.value(value: notificationService),
      ],
      child: FileDropMainApp(
        storageService: storageService,
        notificationService: notificationService,
        discoveryService: discoveryService,
        httpService: httpService,
        fileService: fileService,
      ),
    ),
  );
}

class FileDropMainApp extends StatelessWidget {
  final StorageService storageService;
  final NotificationService notificationService;
  final DiscoveryService discoveryService;
  final HttpService httpService;
  final FileService fileService;

  const FileDropMainApp({
    super.key,
    required this.storageService,
    required this.notificationService,
    required this.discoveryService,
    required this.httpService,
    required this.fileService,
  });

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'FileDrop',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light,
      darkTheme: AppTheme.dark,
      themeMode: storageService.getThemeMode(),
      home: AppRoot(
        discoveryService: discoveryService,
        httpService: httpService,
        fileService: fileService,
        notificationService: notificationService,
        storageService: storageService,
      ),
    );
  }
}
