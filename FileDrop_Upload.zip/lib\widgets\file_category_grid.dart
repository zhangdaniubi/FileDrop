import 'package:flutter/material.dart';

class FileCategoryGrid extends StatelessWidget {
  final void Function(String category) onCategoryTap;

  const FileCategoryGrid({super.key, required this.onCategoryTap});

  static const List<_Category> _categories = [
    _Category('照片', Icons.image_rounded, Color(0xFF4CAF50)),
    _Category('音频', Icons.audiotrack_rounded, Color(0xFF2196F3)),
    _Category('文档', Icons.description_rounded, Color(0xFFFF9800)),
    _Category('其他', Icons.folder_rounded, Color(0xFF9C27B0)),
  ];

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        childAspectRatio: 1.2,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
      ),
      itemCount: _categories.length,
      itemBuilder: (context, index) {
        final cat = _categories[index];
        return Card(
          child: InkWell(
            borderRadius: BorderRadius.circular(12),
            onTap: () => onCategoryTap(cat.name),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 56,
                  height: 56,
                  decoration: BoxDecoration(
                    color: cat.color.withAlpha(30),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Icon(cat.icon, size: 28, color: cat.color),
                ),
                const SizedBox(height: 12),
                Text(
                  cat.name,
                  style: Theme.of(context).textTheme.titleSmall?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _Category {
  final String name;
  final IconData icon;
  final Color color;

  const _Category(this.name, this.icon, this.color);
}
