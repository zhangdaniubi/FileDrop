import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

import 'file_service.dart';

class HttpService {
  HttpServer? _server;
  bool _serverRunning = false;

  final StreamController<Map<String, dynamic>> _receiveController =
      StreamController<Map<String, dynamic>>.broadcast();

  Stream<Map<String, dynamic>> get onFileReceived => _receiveController.stream;

  Future<void> startHttpServer(FileService fileService) async {
    if (_serverRunning) return;
    try {
      _server = await HttpServer.bind(InternetAddress.anyIPv4, 9121);
      _serverRunning = true;
      debugPrint('[FileDrop] HTTP server started on port 9121');

      await for (final request in _server!) {
        _handleRequest(request, fileService);
      }
    } catch (e) {
      debugPrint('[FileDrop] HTTP server error: $e');
    }
  }

  void stopHttpServer() {
    _serverRunning = false;
    _server?.close();
    _server = null;
    debugPrint('[FileDrop] HTTP server stopped');
  }

  void _handleRequest(HttpRequest request, FileService fileService) async {
    try {
      final uri = Uri.parse(request.uri.toString());
      final path = uri.path;

      if (request.method == 'POST' && path == '/api/upload') {
        await _handleUpload(request, fileService);
      } else if (request.method == 'GET' && path == '/api/device/info') {
        _sendJson(request, {
          'code': 0,
          'message': 'ok',
          'data': {
            'deviceId': 'mobile',
            'deviceName': '我的手机',
            'deviceType': 'Phone',
            'osVersion': 'Android',
            'platform': 'mobile',
            'ipAddress': '0.0.0.0',
            'httpPort': 9121,
            'isOnline': true,
          },
        });
      } else {
        _sendJson(request, {'code': 4002, 'message': 'Not found'}, 404);
      }
    } catch (e) {
      debugPrint('[FileDrop] Request handler error: $e');
      _sendJson(request, {'code': 4001, 'message': 'Internal error'}, 500);
    }
  }

  Future<void> _handleUpload(HttpRequest request, FileService fileService) async {
    final contentType = request.headers.contentType;
    if (contentType == null || !contentType.mimeType.contains('multipart')) {
      _sendJson(request, {'code': 4002, 'message': 'Expected multipart upload'}, 400);
      return;
    }

    try {
      final boundary = contentType.parameters['boundary'] ?? '';
      final transformer = MimeMultipartTransformer(boundary);
      final parts = await transformer.bind(request).toList();

      for (final part in parts) {
        final headers = part.headers;
        final disposition = headers['content-disposition'] ?? '';
        final fileNameMatch = RegExp(r'filename="?(.+?)"?$', multiLine: false)
            .firstMatch(disposition);
        final fileName = fileNameMatch?.group(1) ?? 'unknown';

        final bytes = await part.toList();
        int totalSize = 0;
        for (final chunk in bytes) {
          totalSize += chunk.length;
        }

        final allBytes = BytesBuilder();
        for (final chunk in bytes) {
          allBytes.add(chunk);
        }

        final savedPath = await fileService.saveReceivedFile(
          fileName,
          allBytes.toBytes(),
        );

        _receiveController.add({
          'fileName': fileName,
          'fileSize': totalSize,
          'savedPath': savedPath,
        });
      }

      _sendJson(request, {'code': 0, 'message': 'ok', 'data': {'status': 'received'}});
    } catch (e) {
      debugPrint('[FileDrop] Upload error: $e');
      _sendJson(request, {'code': 2003, 'message': 'File write failed'}, 500);
    }
  }

  Future<Map<String, dynamic>> uploadFile({
    required String ip,
    required int port,
    required String filePath,
    required String fileName,
    void Function(int progress, double speed)? onProgress,
  }) async {
    try {
      final file = File(filePath);
      final fileSize = await file.length();
      final uri = Uri.parse('http://$ip:$port/api/upload');
      final request = http.MultipartRequest('POST', uri);

      request.files.add(await http.MultipartFile.fromPath('file', filePath));

      final streamedResponse = await request.send();
      final response = await http.Response.fromStream(streamedResponse);

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['data'] ?? {};
      } else {
        return {'error': 'HTTP ${response.statusCode}'};
      }
    } catch (e) {
      return {'error': e.toString()};
    }
  }

  void _sendJson(HttpRequest request, Map<String, dynamic> data, [int status = 200]) {
    request.response.statusCode = status;
    request.response.headers.contentType = ContentType.json;
    request.response.write(jsonEncode(data));
    request.response.close();
  }

  void dispose() {
    stopHttpServer();
    _receiveController.close();
  }
}
