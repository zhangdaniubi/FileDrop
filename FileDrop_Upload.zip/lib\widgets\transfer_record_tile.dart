import 'package:flutter/material.dart';
import '../models/transfer_record_model.dart';
import '../services/file_service.dart';

class TransferRecordTile extends StatelessWidget {
  final TransferRecord record;
  final VoidCallback? onDelete;

  const TransferRecordTile({
    super.key,
    required this.record,
    this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;

    String getDirectionLabel() {
      return record.direction == 'send' ? '发送' : '接收';
    }

    IconData getDirectionIcon() {
      return record.direction == 'send'
          ? Icons.arrow_upward_rounded
          : Icons.arrow_downward_rounded;
    }

    IconData getStatusIcon() {
      switch (record.status) {
        case 'completed':
          return Icons.check_circle_rounded;
        case 'failed':
          return Icons.error_rounded;
        default:
          return Icons.schedule_rounded;
      }
    }

    Color getStatusColor() {
      switch (record.status) {
        case 'completed':
          return Colors.green;
        case 'failed':
          return Colors.red;
        default:
          return colorScheme.outline;
      }
    }

    String formatTime() {
      final now = DateTime.now();
      final diff = now.difference(record.createdAt);
      if (diff.inMinutes < 1) return '刚刚';
      if (diff.inHours < 1) return '${diff.inMinutes}分钟前';
      if (diff.inDays < 1) return '${diff.inHours}小时前';
      return '${record.createdAt.month}/${record.createdAt.day}';
    }

    return Card(
      margin: const EdgeInsets.only(bottom: 4),
      child: ListTile(
        leading: Icon(getDirectionIcon(), color: colorScheme.primary, size: 20),
        title: Text(
          record.fileName,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(fontSize: 14),
        ),
        subtitle: Text(
          '${record.fileSize} • ${getDirectionLabel()}到 ${record.peerDeviceName} • ${formatTime()}',
          style: TextStyle(fontSize: 12, color: colorScheme.outline),
        ),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(getStatusIcon(), size: 18, color: getStatusColor()),
            if (onDelete != null)
              PopupMenuButton<String>(
                onSelected: (val) {
                  if (val == 'delete') onDelete!();
                },
                itemBuilder: (_) => [
                  const PopupMenuItem(
                    value: 'delete',
                    child: Row(
                      children: [
                        Icon(Icons.delete_rounded, size: 18, color: Colors.red),
                        SizedBox(width: 8),
                        Text('删除'),
                      ],
                    ),
                  ),
                ],
              ),
          ],
        ),
        dense: true,
      ),
    );
  }
}
