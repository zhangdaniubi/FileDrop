import 'package:flutter/foundation.dart';
import '../models/device_model.dart';
import '../services/discovery_service.dart';

class DeviceProvider extends ChangeNotifier {
  final DiscoveryService _discoveryService;
  List<DeviceInfo> _devices = [];
  DeviceInfo? _selectedDevice;

  DeviceProvider(this._discoveryService) {
    _discoveryService.deviceStream.listen((devices) {
      _devices = devices;
      notifyListeners();
    });

    _discoveryService.deviceAdded.listen((device) {
      notifyListeners();
    });

    _discoveryService.deviceRemoved.listen((deviceId) {
      if (_selectedDevice?.deviceId == deviceId) {
        _selectedDevice = null;
      }
      notifyListeners();
    });
  }

  List<DeviceInfo> get devices => List.unmodifiable(_devices);
  DeviceInfo? get selectedDevice => _selectedDevice;
  int get onlineCount => _devices.where((d) => d.isOnline).length;

  void selectDevice(DeviceInfo? device) {
    _selectedDevice = device;
    notifyListeners();
  }

  void refreshDevices() {
    _discoveryService.sendDiscoveryRequest();
  }

  List<DeviceInfo> get onlineDevices =>
      _devices.where((d) => d.isOnline).toList();
}
