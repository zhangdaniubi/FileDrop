import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class StorageService {
  SharedPreferences? _prefs;

  Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
  }

  // 设备昵称
  String get deviceName => _prefs?.getString('device_name') ?? '';
  set deviceName(String value) => _prefs?.setString('device_name', value);

  // 暗色模式
  bool get isDarkMode => _prefs?.getBool('dark_mode') ?? false;
  set isDarkMode(bool value) => _prefs?.setBool('dark_mode', value);

  ThemeMode getThemeMode() => isDarkMode ? ThemeMode.dark : ThemeMode.light;

  // 下载路径
  String get downloadPath => _prefs?.getString('download_path') ?? '';
  set downloadPath(String value) => _prefs?.setString('download_path', value);

  // 自动接收
  bool get autoAccept => _prefs?.getBool('auto_accept') ?? false;
  set autoAccept(bool value) => _prefs?.setBool('auto_accept', value);

  // 传输历史 (JSON 字符串)
  String get transferHistory => _prefs?.getString('transfer_history') ?? '[]';
  set transferHistory(String value) => _prefs?.setString('transfer_history', value);

  // WebSocket 连接的桌面端 IP
  String get lastConnectedIp => _prefs?.getString('last_ip') ?? '';
  set lastConnectedIp(String value) => _prefs?.setString('last_ip', value);

  // 清除所有设置
  Future<void> clearAll() async {
    await _prefs?.clear();
  }
}
