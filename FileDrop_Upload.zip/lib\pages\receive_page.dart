import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';

import '../services/file_service.dart';

class ReceivePage extends StatefulWidget {
  const ReceivePage({super.key});

  @override
  State<ReceivePage> createState() => _ReceivePageState();
}

class _ReceivePageState extends State<ReceivePage> {
  final List<Map<String, dynamic>> _receivedFiles = [];
  StreamSubscription? _subscription;

  @override
  void initState() {
    super.initState();
    // 将在 HttpService 初始化后订阅接收事件
  }

  @override
  void dispose() {
    _subscription?.cancel();
    super.dispose();
  }

  void addReceivedFile(Map<String, dynamic> info) {
    setState(() {
      _receivedFiles.insert(0, info);
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_receivedFiles.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.inbox_rounded,
                size: 64, color: Theme.of(context).colorScheme.outline),
            const SizedBox(height: 16),
            Text(
              '暂无接收文件',
              style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                    color: Theme.of(context).colorScheme.outline,
                  ),
            ),
            const SizedBox(height: 8),
            Text(
              '当其他设备向您发送文件时，\n文件将显示在这里',
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Theme.of(context).colorScheme.outline,
                  ),
            ),
          ],
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _receivedFiles.length,
      itemBuilder: (context, index) {
        final file = _receivedFiles[index];
        return Card(
          child: ListTile(
            leading: const Icon(Icons.insert_drive_file_rounded),
            title: Text(file['fileName'] ?? ''),
            subtitle: Text(
              '${FileService.formatFileSize(file['fileSize'] ?? 0)} • 已保存',
            ),
            trailing: IconButton(
              icon: const Icon(Icons.folder_open_rounded),
              tooltip: '打开文件位置',
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('文件已保存到: ${file['savedPath'] ?? ''}')),
                );
              },
            ),
          ),
        );
      },
    );
  }
}
