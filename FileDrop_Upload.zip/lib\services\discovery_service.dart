import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:device_info_plus/device_info_plus.dart';

import '../models/device_model.dart';

class DiscoveryService {
  static const int udpPort = 9120;
  static const int httpPort = 9121;
  static const Duration heartbeatInterval = Duration(seconds: 3);
  static const Duration offlineTimeout = Duration(seconds: 15);

  RawDatagramSocket? _socket;
  bool _running = false;
  Timer? _heartbeatTimer;
  String? _deviceId;
  String? _deviceName;

  final List<DeviceInfo> _devices = [];
  final StreamController<List<DeviceInfo>> _deviceStreamController =
      StreamController<List<DeviceInfo>>.broadcast();
  final StreamController<DeviceInfo> _deviceAddedController =
      StreamController<DeviceInfo>.broadcast();
  final StreamController<String> _deviceRemovedController =
      StreamController<String>.broadcast();

  Stream<List<DeviceInfo>> get deviceStream => _deviceStreamController.stream;
  Stream<DeviceInfo> get deviceAdded => _deviceAddedController.stream;
  Stream<String> get deviceRemoved => _deviceRemovedController.stream;
  List<DeviceInfo> get devices => List.unmodifiable(_devices);

  Future<String> _getDeviceId() async {
    if (_deviceId != null) return _deviceId!;
    try {
      final info = await DeviceInfoPlugin().androidInfo;
      _deviceId = info.id ?? 'android-${DateTime.now().millisecondsSinceEpoch}';
    } catch (_) {
      _deviceId = 'android-${DateTime.now().millisecondsSinceEpoch}';
    }
    return _deviceId!;
  }

  Future<String> _getDeviceName() async {
    if (_deviceName != null) return _deviceName!;
    try {
      final info = await DeviceInfoPlugin().androidInfo;
      _deviceName = info.model ?? 'Android Phone';
    } catch (_) {
      _deviceName = '我的手机';
    }
    return _deviceName!;
  }

  String getLocalIp() {
    try {
      final interfaces = NetworkInterface.list();
      for (final iface in interfaces) {
        for (final addr in iface.addresses) {
          if (addr.type == InternetAddressType.ipv4 &&
              addr.address.startsWith('192.168.')) {
            return addr.address;
          }
        }
        for (final addr in iface.addresses) {
          if (addr.type == InternetAddressType.ipv4 &&
              (addr.address.startsWith('10.') || addr.address.startsWith('172.'))) {
            return addr.address;
          }
        }
      }
    } catch (e) {
      debugPrint('Get local IP error: $e');
    }
    return '127.0.0.1';
  }

  Future<void> start() async {
    if (_running) return;
    _running = true;

    _deviceId = await _getDeviceId();
    _deviceName = await _getDeviceName();

    try {
      _socket = await RawDatagramSocket.bind(InternetAddress.anyIPv4, udpPort);
      _socket!.broadcastEnabled = true;

      _socket!.listen((event) {
        if (event == RawSocketEvent.read) {
          final datagram = _socket!.receive();
          if (datagram != null) {
            _handleMessage(datagram);
          }
        }
      });

      _sendPresence('announce');

      _heartbeatTimer = Timer.periodic(heartbeatInterval, (_) {
        _sendPresence('heartbeat');
        _checkOfflineDevices();
      });

      debugPrint('[FileDrop] Discovery service started on UDP $udpPort');
    } catch (e) {
      debugPrint('[FileDrop] Discovery start error: $e');
      _running = false;
    }
  }

  void stop() {
    if (!_running) return;
    _running = false;
    _sendPresence('goodbye');
    _heartbeatTimer?.cancel();
    _socket?.close();
    _socket = null;
    _devices.clear();
    debugPrint('[FileDrop] Discovery service stopped');
  }

  void sendDiscoveryRequest() {
    _sendPresence('discover');
  }

  void _sendPresence(String type) {
    if (_socket == null) return;
    try {
      final msg = jsonEncode({
        'type': type,
        'deviceId': _deviceId ?? 'mobile',
        'deviceName': _deviceName ?? '手机',
        'deviceType': 'Phone',
        'osVersion': 'Android',
        'platform': 'mobile',
        'ipAddress': getLocalIp(),
        'httpPort': httpPort,
        'timestamp': DateTime.now().toUtc().toIso8601String(),
      });
      final data = utf8.encode(msg);
      _socket!.send(data, InternetAddress('255.255.255.255'), udpPort);
    } catch (e) {
      debugPrint('UDP send error: $e');
    }
  }

  void _handleMessage(Datagram datagram) {
    try {
      final msg = utf8.decode(datagram.data);
      final data = jsonDecode(msg) as Map<String, dynamic>;
      final senderId = data['deviceId'] ?? '';
      if (senderId == _deviceId) return;

      final type = data['type'] ?? '';

      if (type == 'announce' || type == 'heartbeat' || type == 'discover_response') {
        final device = DeviceInfo.fromJson(data);
        device.ipAddress = datagram.address.address;

        final index = _devices.indexWhere((d) => d.deviceId == device.deviceId);
        if (index >= 0) {
          _devices[index].isOnline = true;
          _devices[index].lastSeen = DateTime.now();
          _devices[index].ipAddress = device.ipAddress;
        } else {
          _devices.add(device);
          _deviceAddedController.add(device);
        }

        if (type == 'discover') {
          _sendPresence('discover_response');
        }

        _deviceStreamController.add(List.from(_devices));

      } else if (type == 'goodbye') {
        _devices.removeWhere((d) => d.deviceId == senderId);
        _deviceRemovedController.add(senderId);
        _deviceStreamController.add(List.from(_devices));
      }
    } catch (e) {
      debugPrint('UDP parse error: $e');
    }
  }

  void _checkOfflineDevices() {
    final now = DateTime.now();
    bool changed = false;
    for (final device in _devices) {
      if (device.isOnline && now.difference(device.lastSeen) > offlineTimeout) {
        device.isOnline = false;
        changed = true;
      }
    }
    if (changed) {
      _deviceStreamController.add(List.from(_devices));
    }
  }

  void dispose() {
    stop();
    _deviceStreamController.close();
    _deviceAddedController.close();
    _deviceRemovedController.close();
  }
}
