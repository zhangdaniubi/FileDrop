class TransferTask {
  final String taskId;
  String fileName;
  int fileSize;
  String direction;
  String targetDeviceId;
  String targetDeviceName;
  String status;
  int progress;
  double speed;
  DateTime createdAt;
  DateTime? completedAt;

  TransferTask({
    required this.taskId,
    required this.fileName,
    this.fileSize = 0,
    required this.direction,
    this.targetDeviceId = '',
    this.targetDeviceName = '',
    this.status = 'pending',
    this.progress = 0,
    this.speed = 0,
    DateTime? createdAt,
    this.completedAt,
  }) : createdAt = createdAt ?? DateTime.now();

  String get formattedSize {
    if (fileSize < 1024) return '$fileSize B';
    if (fileSize < 1024 * 1024) return '${(fileSize / 1024).toStringAsFixed(1)} KB';
    if (fileSize < 1024 * 1024 * 1024) {
      return '${(fileSize / (1024 * 1024)).toStringAsFixed(1)} MB';
    }
    return '${(fileSize / (1024 * 1024 * 1024)).toStringAsFixed(1)} GB';
  }

  String get formattedSpeed {
    if (speed < 1024) return '${speed.toStringAsFixed(0)} B/s';
    if (speed < 1024 * 1024) return '${(speed / 1024).toStringAsFixed(1)} KB/s';
    return '${(speed / (1024 * 1024)).toStringAsFixed(1)} MB/s';
  }

  bool get isActive => status == 'pending' || status == 'transferring';
  bool get isCompleted => status == 'completed';
  bool get isFailed => status == 'failed';

  Map<String, dynamic> toJson() => {
    'taskId': taskId,
    'fileName': fileName,
    'fileSize': fileSize,
    'direction': direction,
    'targetDeviceId': targetDeviceId,
    'targetDeviceName': targetDeviceName,
    'status': status,
    'progress': progress,
    'speed': speed,
    'createdAt': createdAt.toIso8601String(),
    'completedAt': completedAt?.toIso8601String(),
  };

  factory TransferTask.fromJson(Map<String, dynamic> json) => TransferTask(
    taskId: json['taskId'] ?? '',
    fileName: json['fileName'] ?? '',
    fileSize: json['fileSize'] ?? 0,
    direction: json['direction'] ?? 'send',
    targetDeviceId: json['targetDeviceId'] ?? '',
    targetDeviceName: json['targetDeviceName'] ?? '',
    status: json['status'] ?? 'pending',
    progress: json['progress'] ?? 0,
    speed: (json['speed'] ?? 0).toDouble(),
    createdAt: json['createdAt'] != null ? DateTime.tryParse(json['createdAt']) : null,
    completedAt: json['completedAt'] != null ? DateTime.tryParse(json['completedAt']) : null,
  );
}
