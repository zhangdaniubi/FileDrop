import 'package:flutter/material.dart';

class ConnectionStatusBar extends StatelessWidget {
  final int deviceCount;

  const ConnectionStatusBar({super.key, required this.deviceCount});

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;

    final bool connected = deviceCount > 0;

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      decoration: BoxDecoration(
        color: connected
            ? Colors.green.withAlpha(15)
            : colorScheme.surfaceContainerHighest,
        border: Border(
          bottom: BorderSide(
            color: colorScheme.outlineVariant,
            width: 0.5,
          ),
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 8,
            height: 8,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: connected ? Colors.green : Colors.orange,
            ),
          ),
          const SizedBox(width: 8),
          Text(
            connected
                ? '已连接 $deviceCount 台设备'
                : '正在搜索局域网设备...',
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: connected ? Colors.green.shade700 : colorScheme.outline,
                  fontWeight: connected ? FontWeight.w600 : FontWeight.normal,
                ),
          ),
          const Spacer(),
          // 局域网/互联网模式切换
          // Chip(label: Text('局域网', style: TextStyle(fontSize: 11)), visualDensity: VisualDensity.compact),
          if (!connected)
            SizedBox(
              width: 14,
              height: 14,
              child: CircularProgressIndicator(
                strokeWidth: 2,
                color: colorScheme.outline,
              ),
            ),
        ],
      ),
    );
  }
}
