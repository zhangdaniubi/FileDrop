import 'package:flutter/foundation.dart';
import '../models/transfer_task_model.dart';

class TransferProvider extends ChangeNotifier {
  final List<TransferTask> _activeTasks = [];

  List<TransferTask> get activeTasks => List.unmodifiable(_activeTasks);
  List<TransferTask> get transferringTasks =>
      _activeTasks.where((t) => t.status == 'transferring').toList();

  void addTask(TransferTask task) {
    _activeTasks.insert(0, task);
    notifyListeners();
  }

  void updateProgress(String taskId, int progress, double speed) {
    final task = _activeTasks.firstWhere(
      (t) => t.taskId == taskId,
      orElse: () => TransferTask(taskId: '', fileName: '', direction: ''),
    );
    if (task.taskId.isNotEmpty) {
      task.progress = progress;
      task.speed = speed;
      task.status = 'transferring';
      notifyListeners();
    }
  }

  void completeTask(String taskId, String status) {
    final task = _activeTasks.firstWhere(
      (t) => t.taskId == taskId,
      orElse: () => TransferTask(taskId: '', fileName: '', direction: ''),
    );
    if (task.taskId.isNotEmpty) {
      task.status = status;
      task.progress = 100;
      task.completedAt = DateTime.now();
      notifyListeners();
    }
  }

  void cancelTask(String taskId) {
    _activeTasks.removeWhere((t) => t.taskId == taskId);
    notifyListeners();
  }

  void removeCompleted() {
    _activeTasks.removeWhere((t) => t.status == 'completed' || t.status == 'failed');
    notifyListeners();
  }

  bool get hasActiveTransfer =>
      _activeTasks.any((t) => t.status == 'pending' || t.status == 'transferring');
}
