# FileDrop 移动端

## 如何获取 APK 安装包（免费，不需要装任何软件）

### 方法一：使用 GitHub Actions 自动编译（推荐）

**第 1 步：注册 GitHub 账号**
1. 打开 https://github.com
2. 点击 "Sign up"，输入邮箱、密码，注册一个账号（免费）

**第 2 步：创建仓库并上传代码**
1. 登录 GitHub 后，点击右上角 "+" → "New repository"
2. Repository name 填 `FileDrop`
3. 勾选 "Public"（选 Private 也行但免费版有限制）
4. 点击 "Create repository"
5. 在新页面往下翻，找到 "uploading an existing file"，点击
6. 把 `file_drop_mobile` 文件夹里**所有文件和文件夹**拖进去
7. 拉到页面底部，点 "Commit changes"

**第 3 步：等待自动编译**
1. 上传完后，点击顶部 "Actions" 标签
2. 你会看到一个 "构建 FileDrop APK" 正在运行（黄色圆点）
3. 等它变成绿色勾勾（约 5-10 分钟）
4. 点击这个绿色的工作流，往下翻到 "Artifacts"
5. 点击 "FileDrop-APK" 下载 zip 包
6. 解压后里面就是 `app-debug.apk`

**手机安装 APK**
1. 把 APK 传到手机（微信发给自己、或者用数据线拷贝）
2. 在手机上点击 APK 文件安装
3. 如果提示"未知来源应用"，去设置里允许安装即可

### 方法二：有 Flutter 开发环境的电脑

```bash
cd file_drop_mobile
flutter create --project-name=file_drop_mobile .
flutter build apk --debug
```

APK 生成在 `build/app/outputs/flutter-apk/app-debug.apk`
