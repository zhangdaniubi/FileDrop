import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:file_picker/file_picker.dart';

import '../providers/device_provider.dart';
import '../models/device_model.dart';
import 'device_page.dart';
import 'receive_page.dart';
import 'history_page.dart';
import 'settings_page.dart';
import 'send_page.dart';
import '../widgets/connection_status_bar.dart';
import '../widgets/file_category_grid.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _currentIndex = 0;

  final List<Widget> _pages = const [
    _SendTab(),
    _ReceiveTab(),
    _HistoryTab(),
    _SettingsTab(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Consumer<DeviceProvider>(
              builder: (context, provider, _) {
                return ConnectionStatusBar(deviceCount: provider.onlineCount);
              },
            ),
            Expanded(
              child: IndexedStack(index: _currentIndex, children: _pages),
            ),
          ],
        ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _currentIndex,
        onDestinationSelected: (index) => setState(() => _currentIndex = index),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.send_rounded), label: '发送'),
          NavigationDestination(icon: Icon(Icons.download_rounded), label: '接收'),
          NavigationDestination(icon: Icon(Icons.history_rounded), label: '记录'),
          NavigationDestination(icon: Icon(Icons.settings_rounded), label: '设置'),
        ],
      ),
    );
  }
}

class _SendTab extends StatelessWidget {
  const _SendTab();

  void _selectFile(BuildContext context, String category) async {
    FileType fileType;
    List<String>? allowedExtensions;

    switch (category) {
      case '照片':
        fileType = FileType.image;
        break;
      case '音频':
        fileType = FileType.audio;
        break;
      case '文档':
        fileType = FileType.custom;
        allowedExtensions = ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'txt'];
        break;
      default:
        fileType = FileType.any;
    }

    final result = await FilePicker.platform.pickFiles(
      type: fileType,
      allowedExtensions: allowedExtensions,
      allowMultiple: true,
    );

    if (result != null && result.files.isNotEmpty && context.mounted) {
      final deviceProvider = context.read<DeviceProvider>();
      final targetDevice = deviceProvider.selectedDevice;

      if (targetDevice == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('请先在设备列表中选择目标设备')),
        );
        return;
      }

      if (!context.mounted) return;
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (_) => SendPage(files: result.files, targetDevice: targetDevice),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 8),
          Text('选择文件类型', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 16),
          Expanded(
            child: FileCategoryGrid(onCategoryTap: (cat) => _selectFile(context, cat)),
          ),
        ],
      ),
    );
  }
}

class _ReceiveTab extends StatelessWidget {
  const _ReceiveTab();

  @override
  Widget build(BuildContext context) => const ReceivePage();
}

class _HistoryTab extends StatelessWidget {
  const _HistoryTab();

  @override
  Widget build(BuildContext context) => const HistoryPage();
}

class _SettingsTab extends StatelessWidget {
  const _SettingsTab();

  @override
  Widget build(BuildContext context) => const SettingsPage();
}
