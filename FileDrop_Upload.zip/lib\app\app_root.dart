import 'package:flutter/material.dart';

import '../services/discovery_service.dart';
import '../services/http_service.dart';
import '../services/file_service.dart';
import '../services/notification_service.dart';
import '../services/storage_service.dart';
import '../pages/home_page.dart';

class AppRoot extends StatefulWidget {
  final DiscoveryService discoveryService;
  final HttpService httpService;
  final FileService fileService;
  final NotificationService notificationService;
  final StorageService storageService;

  const AppRoot({
    super.key,
    required this.discoveryService,
    required this.httpService,
    required this.fileService,
    required this.notificationService,
    required this.storageService,
  });

  @override
  State<AppRoot> createState() => _AppRootState();
}

class _AppRootState extends State<AppRoot> {
  @override
  void initState() {
    super.initState();
    _initServices();
  }

  Future<void> _initServices() async {
    try {
      await widget.discoveryService.start();
    } catch (e) {
      debugPrint('Discovery service error: $e');
    }
    try {
      await widget.httpService.startHttpServer(widget.fileService);
    } catch (e) {
      debugPrint('HTTP server error: $e');
    }
  }

  @override
  void dispose() {
    widget.discoveryService.stop();
    widget.httpService.stopHttpServer();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return const HomePage();
  }
}
