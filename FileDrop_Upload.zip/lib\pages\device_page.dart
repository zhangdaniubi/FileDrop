import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/device_provider.dart';
import '../widgets/device_card.dart';

class DevicePage extends StatelessWidget {
  const DevicePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<DeviceProvider>(
      builder: (context, provider, _) {
        final devices = provider.onlineDevices;

        return RefreshIndicator(
          onRefresh: () async {
            provider.refreshDevices();
            await Future.delayed(const Duration(seconds: 1));
          },
          child: devices.isEmpty
              ? ListView(
                  children: [
                    SizedBox(
                      height: MediaQuery.of(context).size.height * 0.4,
                      child: Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.wifi_find_rounded,
                                size: 64, color: Theme.of(context).colorScheme.outline),
                            const SizedBox(height: 16),
                            Text(
                              '正在搜索局域网设备...',
                              style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                                    color: Theme.of(context).colorScheme.outline,
                                  ),
                            ),
                            const SizedBox(height: 8),
                            const LinearProgressIndicator(),
                          ],
                        ),
                      ),
                    ),
                  ],
                )
              : ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: devices.length,
                  itemBuilder: (context, index) {
                    final device = devices[index];
                    final isSelected = provider.selectedDevice?.deviceId == device.deviceId;

                    return DeviceCard(
                      device: device,
                      isSelected: isSelected,
                      onTap: () => provider.selectDevice(device),
                    );
                  },
                ),
        );
      },
    );
  }
}
