import 'dart:convert';
import 'package:flutter/foundation.dart';
import '../models/transfer_record_model.dart';
import '../services/storage_service.dart';

class HistoryProvider extends ChangeNotifier {
  final StorageService _storageService;
  List<TransferRecord> _records = [];

  HistoryProvider(this._storageService) {
    loadFromStorage();
  }

  List<TransferRecord> get records => List.unmodifiable(_records);

  List<TransferRecord> getRecent(int count) {
    final sorted = List<TransferRecord>.from(_records)
      ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
    return sorted.take(count).toList();
  }

  void addRecord(TransferRecord record) {
    record.id = DateTime.now().millisecondsSinceEpoch;
    _records.insert(0, record);
    if (_records.length > 30) {
      _records = _records.sublist(0, 30);
    }
    saveToStorage();
    notifyListeners();
  }

  void removeRecord(int id) {
    _records.removeWhere((r) => r.id == id);
    saveToStorage();
    notifyListeners();
  }

  void clearAll() {
    _records.clear();
    saveToStorage();
    notifyListeners();
  }

  void loadFromStorage() {
    try {
      final jsonStr = _storageService.transferHistory;
      final list = jsonDecode(jsonStr) as List<dynamic>;
      _records = list
          .map((e) => TransferRecord.fromJson(e as Map<String, dynamic>))
          .toList();
    } catch (e) {
      _records = [];
    }
  }

  void saveToStorage() {
    try {
      final jsonStr = jsonEncode(_records.map((r) => r.toJson()).toList());
      _storageService.transferHistory = jsonStr;
    } catch (e) {
      debugPrint('History save error: $e');
    }
  }
}
